package com.example.vijha.stockwatch;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by vijha on 3/1/2018.
 */

public class AsyncLoaderTask extends AsyncTask<String, Void, String> {

    private static final String TAG = "";
    private MainActivity mainActivity;
    private int count;

    private static String stocksearch = "http://d.yimg.com/aq/autoc?region=US&lang=en-US&query=";


    public AsyncLoaderTask(MainActivity ma)
    {
        mainActivity = ma;
    }

    @Override
    protected void onPreExecute()
    {
    }

    @Override
    protected void onPostExecute(String sb)
    {
        if (sb == null)
        {
            mainActivity.noSymbolFound();

        }
        else
        {
            ArrayList<Stock> stockArrayList = parseJSON(sb);
            mainActivity.chooseSymbol(stockArrayList);
        }
    }

    @Override
    protected String doInBackground(String... params)
    {
        Uri symbolUri = Uri.parse(stocksearch + params[0]);
        Log.d(TAG, String.valueOf(Uri.parse(stocksearch + params[0])));
        String urlToUse = symbolUri.toString();
        StringBuilder sb = new StringBuilder();
        try
        {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;


            while ((line = reader.readLine()) != null)
            {
                sb.append(line);
            }
        }
        catch (Exception e)
        {
            return null;
        }
        Log.d(TAG, "inside doinBackground");
        return sb.toString();
    }


    private ArrayList<Stock> parseJSON(String s)
    {
        ArrayList<Stock> stockArrayList = new ArrayList<>();
        try
        {
            JSONObject jsonObject = new JSONObject(s);
            JSONArray jArray = jsonObject.getJSONObject("ResultSet").getJSONArray("Result");
            for (int i = 0; i < jArray.length(); i++)
            {
                JSONObject jStock = (JSONObject) jArray.get(i);
                if(jStock.getString("type").equals("S"))
                {
                    String name = jStock.getString("name");
                    String symbol = jStock.getString("symbol");
                    Log.d(TAG, "Inside parseJASON" + i);
                    stockArrayList.add(
                            new Stock(symbol, name));
                }
            }
            return stockArrayList;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

}
